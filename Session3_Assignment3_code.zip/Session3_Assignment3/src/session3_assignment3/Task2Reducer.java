package session3_assignment3;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class Task2Reducer extends Reducer<Text, Text, Text, IntWritable>
{
   public void reduce(Text key, Iterable<Text> values, Context context)
	throws IOException, InterruptedException
	{
	   int count = 0;
	   Text company = new Text("Onida");
	   for (Text value : values)
	   {
		   if(value.equals(company))
		   count = count+1;		   
	   }
	   context.write(key, new IntWritable(count));
	}	   
}